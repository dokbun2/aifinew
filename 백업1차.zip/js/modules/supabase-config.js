// Supabase Configuration
// ⚠️ IMPORTANT: Replace these with your actual Supabase project credentials

const SUPABASE_CONFIG = {
    // Public configuration (safe to expose)
    url: 'https://YOUR_PROJECT_ID.supabase.co',
    anonKey: 'YOUR_ANON_PUBLIC_KEY',

    // Application settings
    app: {
        autoSaveInterval: 5 * 60 * 1000, // 5 minutes in milliseconds
        maxFileSize: 50 * 1024 * 1024, // 50MB
        allowedImageTypes: ['image/jpeg', 'image/png', 'image/webp', 'image/gif'],
        allowedVideoTypes: ['video/mp4', 'video/webm'],
    },

    // Storage buckets
    storage: {
        projectFiles: 'project-files',
        publicAssets: 'public-assets'
    },

    // Default project settings
    defaults: {
        projectType: 'movie',
        status: 'planning',
        statistics: {
            total_sequences: 0,
            total_scenes: 0,
            total_shots: 0,
            total_characters: 0,
            total_locations: 0,
            total_props: 0
        }
    }
};

// Environment detection
const isDevelopment = window.location.hostname === 'localhost' ||
                     window.location.hostname === '127.0.0.1';

// Override for development if needed
if (isDevelopment) {
    console.log('🔧 Running in development mode');
    // You can override settings for development here
}

// Validate configuration
function validateConfig() {
    if (SUPABASE_CONFIG.url === 'https://YOUR_PROJECT_ID.supabase.co') {
        console.error('⚠️ Supabase URL not configured! Please update supabase-config.js');
        return false;
    }
    if (SUPABASE_CONFIG.anonKey === 'YOUR_ANON_PUBLIC_KEY') {
        console.error('⚠️ Supabase Anon Key not configured! Please update supabase-config.js');
        return false;
    }
    return true;
}

// Export configuration
export { SUPABASE_CONFIG, isDevelopment, validateConfig };